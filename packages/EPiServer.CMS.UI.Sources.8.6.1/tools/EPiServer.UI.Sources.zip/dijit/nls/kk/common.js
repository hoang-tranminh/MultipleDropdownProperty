define(
({
	buttonOk: "OK",
	buttonCancel: "Болдырмау",
	buttonSave: "Сақтау",
	itemClose: "Жабу"
})
);
