define(
({
	buttonOk: "OK",
	buttonCancel: "Storno",
	buttonSave: "Uložit",
	itemClose: "Zavřít"
})
);
