define(
({
	loadingState: "Nalaganje ...",
	errorState: "Oprostite, prišlo je do napake."
})
);
