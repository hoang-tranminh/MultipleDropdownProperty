define([
	"dojo/robot"
], function(){
	// module:
	//		dijit/robot
	// summary:
	//		Used to have code needed by robot test harness, but no longer
});
