define(
({
		previousMessage: "Tidigare val",
		nextMessage: "Fler val"
})
);
