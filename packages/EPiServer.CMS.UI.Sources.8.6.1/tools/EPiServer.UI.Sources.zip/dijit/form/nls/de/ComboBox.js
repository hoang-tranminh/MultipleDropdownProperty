define(
({
		previousMessage: "Vorherige Auswahl",
		nextMessage: "Weitere Auswahlmöglichkeiten"
})
);
