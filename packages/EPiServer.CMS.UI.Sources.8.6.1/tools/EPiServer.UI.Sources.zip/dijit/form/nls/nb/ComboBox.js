define(
({
		previousMessage: "Tidligere valg",
		nextMessage: "Flere valg"
})
);
