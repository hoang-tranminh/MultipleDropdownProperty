define(
({
		previousMessage: "Prethodni izbori",
		nextMessage: "Više izbora"
})
);
