define(
({
		previousMessage: "Scelte precedenti",
		nextMessage: "Scelte successive"
})
);
