define({
	root: {
		popupTriggerLabel: 'Show or hide columns',
		popupLabel: 'Show or hide columns'
	},
	es: true,
	ro: true
});
